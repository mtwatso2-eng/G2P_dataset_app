# Get geno
geno <- read.csv('Rice_geno.csv')
dim(geno)

# Get pheno
pheno <- read.csv('Rice-Phenotypes.csv')
head(pheno)
