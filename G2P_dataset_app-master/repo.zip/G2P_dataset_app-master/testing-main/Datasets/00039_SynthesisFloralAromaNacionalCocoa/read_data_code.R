library(readxl)

# Get geno
geno <- read_excel('Cocoa Amazonia Ecuador aroma.xlsx',sheet = 1)
dim(geno)
