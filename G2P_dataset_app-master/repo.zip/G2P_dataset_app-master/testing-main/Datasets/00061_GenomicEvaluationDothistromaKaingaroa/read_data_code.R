# Get geno
geno <- read.csv('SNP_Kaingaroa_release.csv')
head(geno)

# Get pheno
pheno <- read.csv('Phenotype_Kaingaroa_release.csv')
head(pheno)

# Get ped
ped <- read.csv('Pedigree_Kaingaroa_release.csv')
head(ped)
