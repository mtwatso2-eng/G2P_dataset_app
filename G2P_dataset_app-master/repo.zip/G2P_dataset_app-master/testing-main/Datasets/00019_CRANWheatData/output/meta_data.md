# BGLR: Bayesian Generalized Linear Regression

This publication discusses the The BGLR (‘Bayesian Generalized Linear Regression’) function fits various types of parametric and semi-parametric Bayesian regressions to continuos (censored or not), binary and ordinal outcomes
It contains  genotypes and  markers.

Title: BGLR: Bayesian Generalized Linear Regression
Scientific name: 
DOI: https://doi.org/10.32614/CRAN.package.BGLR
Has phenotype 

