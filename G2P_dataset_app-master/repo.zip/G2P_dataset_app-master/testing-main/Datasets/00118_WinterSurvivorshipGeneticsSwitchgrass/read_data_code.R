library(data.table)

# Get geno
geno <- fread('WALS_BSA_ReadCount_SNP_Matrix.txt.gz')
dim(geno)
