library(readxl)

# Get geno
geno <- read_xlsx('SNP_genotypes.xlsx')
dim(geno)
