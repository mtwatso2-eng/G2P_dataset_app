
# Get geno
geno = data.frame()

# Get pheno

