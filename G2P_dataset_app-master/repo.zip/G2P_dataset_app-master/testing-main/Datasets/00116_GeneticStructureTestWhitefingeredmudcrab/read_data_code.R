library(data.table)

# Get geno
geno <- fread('Rhithro_12638_genos.txt')
dim(geno)
