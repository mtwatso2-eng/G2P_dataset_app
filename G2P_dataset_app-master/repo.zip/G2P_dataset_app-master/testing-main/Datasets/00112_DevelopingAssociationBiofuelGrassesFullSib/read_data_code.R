library(data.table)

# Get geno
geno <- fread('pop1_fullsib_0.05_0.5_0_min5_h_e3/HapMap.hmp.txt')
dim(geno)
