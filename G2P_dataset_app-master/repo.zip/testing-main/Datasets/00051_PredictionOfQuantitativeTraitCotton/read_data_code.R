library(readxl)

# Get geno
geno <- read_excel('Table_8_Accurate Prediction of a Quantitative Trait Using the Genes Controlling the Trait for Gene-Based Breeding in Cotton.XLSX')
dim(geno)