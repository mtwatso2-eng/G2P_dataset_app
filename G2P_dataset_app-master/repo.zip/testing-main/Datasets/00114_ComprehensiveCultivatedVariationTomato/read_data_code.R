# Import necessary packages 

# Get geno
geno <- ''
