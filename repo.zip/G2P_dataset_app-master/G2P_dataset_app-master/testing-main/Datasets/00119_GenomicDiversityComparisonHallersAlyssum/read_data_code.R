library(data.table)

# Get geno
geno <- fread('Aha_09_11_18_19_21_31_N1_N3_N4v3_rc')
dim(geno)
