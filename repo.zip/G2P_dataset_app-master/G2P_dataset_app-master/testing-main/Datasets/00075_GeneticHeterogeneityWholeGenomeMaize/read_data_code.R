library(data.table)

# Get geno
geno <- fread('GSE50558_CFD_matrix_GEO.txt')
dim(geno)

